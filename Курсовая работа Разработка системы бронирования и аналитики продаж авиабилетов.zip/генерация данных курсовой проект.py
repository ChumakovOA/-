import mysql.connector
import random
from datetime import datetime, timedelta
from faker import Faker
import time

fake = Faker('ru_RU')

# Настройки подключения
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Qewraz159!',
    'database': 'курсовой_проект',
    'charset': 'utf8mb4',
    'autocommit': False
}

# Количество записей - УВЕЛИЧИЛ ДО МАКСИМУМА
NUM_RECORDS = {
    'aircrafts': 100,             # 100 МОДЕЛЕЙ САМОЛЕТОВ!
    'airports': 200,
    'document_type': 10,
    'tariffs': 15,
    'ticket_type': 8,
    'passengers': 150000,
    'seat_maps': 200,             # 2 карты на самолет
    'seats': 80000,               # Увеличил количество мест
    'flights': 5000,              # Увеличил рейсы
    'seats_on_flight': 300000,    # Увеличил места на рейсах
    'bookings': 300000,           # Увеличил бронирования
    'payments': 220000            # Увеличил платежи
}

def create_connection():
    """Создание подключения к БД"""
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        print("✅ Подключение к БД установлено")
        return conn
    except mysql.connector.Error as err:
        print(f"❌ Ошибка подключения: {err}")
        print(f"Проверьте параметры подключения:")
        print(f"  Хост: {DB_CONFIG['host']}")
        print(f"  Пользователь: {DB_CONFIG['user']}")
        print(f"  База данных: {DB_CONFIG['database']}")
        return None

def clear_existing_data(conn):
    """Очистка всех таблиц перед заполнением"""
    print("🧹 Очищаем существующие данные...")
    
    cursor = conn.cursor()
    cursor.execute("SET FOREIGN_KEY_CHECKS = 0")
    
    tables = [
        'payments', 'bookings', 'seats_on_flight', 'seats', 
        'flights', 'seat_maps', 'passengers', 'airports',
        'ticket_type', 'tariffs', 'aircrafts', 'document_type'
    ]
    
    for table in tables:
        try:
            cursor.execute(f"DELETE FROM {table}")
            print(f"  ✓ Очищена таблица: {table}")
        except Exception as e:
            print(f"  ⚠️ Не удалось очистить {table}: {e}")
    
    cursor.execute("SET FOREIGN_KEY_CHECKS = 1")
    conn.commit()
    cursor.close()
    print("✅ Все таблицы очищены")

def generate_document_types(conn):
    """Заполнение типов документов"""
    print("📄 Заполняем document_type...")
    
    document_types = [
        ('PAS_RU', 'Паспорт РФ', 'RU'),
        ('FOR_PAS', 'Загранпаспорт РФ', 'INT'),
        ('BIRTH', 'Свидетельство о рождении', 'RU'),
        ('MILITARY', 'Военный билет', 'RU'),
        ('SEAMAN', 'Паспорт моряка', 'INT'),
        ('DIPLOMA', 'Дипломатический паспорт', 'INT'),
        ('RESIDENCE', 'Вид на жительство', 'RU'),
        ('OTHER', 'Иной документ', 'VAR'),
        ('ID_CARD', 'Удостоверение личности', 'RU'),
        ('REFUGEE', 'Удостоверение беженца', 'INT')
    ]
    
    cursor = conn.cursor()
    cursor.executemany(
        "INSERT INTO document_type (doc_type_cod, doc_type_name, country_code) VALUES (%s, %s, %s)",
        document_types[:NUM_RECORDS['document_type']]
    )
    conn.commit()
    cursor.close()
    print(f"✓ Добавлено {min(NUM_RECORDS['document_type'], len(document_types))} типов документов")

def generate_aircrafts(conn):
    """Заполнение самолетов - 100 МОДЕЛЕЙ!"""
    print("✈️ Заполняем aircrafts...")
    
    # БОЛЬШЕ МОДЕЛЕЙ САМОЛЕТОВ
    aircraft_models = [
        # Boeing (30 моделей)
        ('Boeing 737-800', 189), ('Boeing 737-900', 215), ('Boeing 737 MAX 8', 178),
        ('Boeing 737 MAX 9', 193), ('Boeing 737-700', 149), ('Boeing 737-600', 132),
        ('Boeing 777-300ER', 396), ('Boeing 777-200', 314), ('Boeing 777-200LR', 317),
        ('Boeing 777-300', 550), ('Boeing 777X', 426), ('Boeing 777-8X', 384),
        ('Boeing 787-9', 296), ('Boeing 787-8', 242), ('Boeing 787-10', 336),
        ('Boeing 747-8', 410), ('Boeing 747-400', 416), ('Boeing 747SP', 331),
        ('Boeing 767-300', 261), ('Boeing 767-400', 304), ('Boeing 767-200', 255),
        ('Boeing 757-200', 200), ('Boeing 757-300', 243), ('Boeing 727-200', 189),
        ('Boeing 707-320', 189), ('Boeing 717-200', 117), ('Boeing 747-100', 366),
        ('Boeing 747-200', 366), ('Boeing 747-300', 366), ('Boeing 747-100B', 366),
        # Airbus (30 моделей)
        ('Airbus A320', 180), ('Airbus A321', 220), ('Airbus A321neo', 244),
        ('Airbus A320neo', 195), ('Airbus A319', 144), ('Airbus A318', 132),
        ('Airbus A330-300', 277), ('Airbus A330-200', 246), ('Airbus A330-900', 287),
        ('Airbus A330-800', 257), ('Airbus A340-300', 295), ('Airbus A340-600', 380),
        ('Airbus A340-500', 313), ('Airbus A340-200', 239), ('Airbus A350-900', 325),
        ('Airbus A350-1000', 369), ('Airbus A350-800', 276), ('Airbus A380-800', 555),
        ('Airbus A380plus', 575), ('Airbus A300-600', 266), ('Airbus A310-300', 240),
        ('Airbus A220-100', 133), ('Airbus A220-300', 160), ('Airbus A319neo', 160),
        ('Airbus A320ceo', 180), ('Airbus A321ceo', 220), ('Airbus A330-200F', 70),
        ('Airbus A300B4', 266), ('Airbus A300-600R', 266), ('Airbus A310-200', 240),
        # Российские (20 моделей)
        ('Sukhoi Superjet 100', 98), ('Sukhoi Superjet 75', 78), ('Sukhoi Superjet 95', 103),
        ('Ил-96-300', 300), ('Ил-96-400', 436), ('Ил-86', 350),
        ('Ту-204', 210), ('Ту-204-100', 210), ('Ту-204-300', 166),
        ('Ту-214', 210), ('Ту-154', 180), ('Ту-154M', 180),
        ('Ту-134', 96), ('Ту-334', 102), ('Ан-148', 85),
        ('Ан-158', 99), ('МС-21-200', 165), ('МС-21-300', 211),
        ('МС-21-400', 256), ('Як-42', 120),
        # Региональные (15 моделей)
        ('Embraer E195', 132), ('Embraer E190', 114), ('Embraer E175', 88),
        ('Embraer E170', 80), ('Embraer E195-E2', 146), ('Embraer E190-E2', 114),
        ('Bombardier CRJ900', 90), ('Bombardier CRJ700', 78), ('Bombardier CRJ1000', 104),
        ('Bombardier CRJ200', 50), ('Bombardier CRJ550', 50), ('ATR 72-600', 72),
        ('ATR 42-600', 48), ('ATR 72-500', 72), ('ATR 42-500', 48),
        # Бизнес-джеты (5 моделей)
        ('Gulfstream G650', 19), ('Bombardier Global 7500', 19), ('Dassault Falcon 8X', 16),
        ('Cessna Citation X+', 12), ('Embraer Legacy 650', 19)
    ]
    
    cursor = conn.cursor()
    
    # Проверяем, нужно ли генерировать больше моделей чем есть
    if NUM_RECORDS['aircrafts'] > len(aircraft_models):
        # Если нужно больше моделей чем есть, дублируем с вариациями
        all_models = aircraft_models.copy()
        while len(all_models) < NUM_RECORDS['aircrafts']:
            model, seats = random.choice(aircraft_models)
            # Создаем вариацию модели
            variant = f"{model} v{random.randint(1, 5)}"
            seats_variant = seats + random.randint(-20, 20)
            all_models.append((variant, max(50, seats_variant)))
        
        selected_models = random.sample(all_models, NUM_RECORDS['aircrafts'])
    else:
        selected_models = random.sample(aircraft_models, NUM_RECORDS['aircrafts'])
    
    for model, seats in selected_models:
        seats_variation = seats + random.randint(-10, 10)
        cursor.execute(
            "INSERT INTO aircrafts (model_of_aircraft, number_of_seats) VALUES (%s, %s)",
            (model, max(50, seats_variation))
        )
    
    conn.commit()
    cursor.close()
    print(f"✓ Добавлено {NUM_RECORDS['aircrafts']} самолетов")

def generate_airports(conn):
    """Заполнение аэропортов"""
    print("🏢 Заполняем airports...")
    
    cursor = conn.cursor()
    
    real_airports = [
        # Российские (50 аэропортов)
        ('SVO', 'Шереметьево', 'Москва', 'Россия'),
        ('DME', 'Домодедово', 'Москва', 'Россия'),
        ('LED', 'Пулково', 'Санкт-Петербург', 'Россия'),
        ('KRR', 'Пашковский', 'Краснодар', 'Россия'),
        ('OVB', 'Толмачёво', 'Новосибирск', 'Россия'),
        ('KZN', 'Казань', 'Казань', 'Россия'),
        ('UFA', 'Уфа', 'Уфа', 'Россия'),
        ('ROV', 'Платов', 'Ростов-на-Дону', 'Россия'),
        ('AER', 'Сочи', 'Сочи', 'Россия'),
        ('VKO', 'Внуково', 'Москва', 'Россия'),
        ('SVX', 'Кольцово', 'Екатеринбург', 'Россия'),
        ('OMS', 'Омск-Центральный', 'Омск', 'Россия'),
        ('KGD', 'Храброво', 'Калининград', 'Россия'),
        ('GOJ', 'Стригино', 'Нижний Новгород', 'Россия'),
        ('CEK', 'Челябинск', 'Челябинск', 'Россия'),
        ('MRV', 'Минеральные Воды', 'Минеральные Воды', 'Россия'),
        ('BAX', 'Барнаул', 'Барнаул', 'Россия'),
        ('VOG', 'Волгоград', 'Волгоград', 'Россия'),
        ('AAQ', 'Анапа', 'Анапа', 'Россия'),
        ('ARH', 'Архангельск', 'Архангельск', 'Россия'),
        ('ASF', 'Астрахань', 'Астрахань', 'Россия'),
        ('BQS', 'Благовещенск', 'Благовещенск', 'Россия'),
        ('CSY', 'Чебоксары', 'Чебоксары', 'Россия'),
        ('DYR', 'Анадырь', 'Анадырь', 'Россия'),
        ('EGO', 'Белгород', 'Белгород', 'Россия'),
        ('EYK', 'Белоярский', 'Белоярский', 'Россия'),
        ('GDX', 'Магадан', 'Магадан', 'Россия'),
        ('GDZ', 'Геленджик', 'Геленджик', 'Россия'),
        ('GRV', 'Грозный', 'Грозный', 'Россия'),
        ('IAR', 'Туношна', 'Ярославль', 'Россия'),
        ('IJK', 'Ижевск', 'Ижевск', 'Россия'),
        ('IKT', 'Иркутск', 'Иркутск', 'Россия'),
        ('KEJ', 'Кемерово', 'Кемерово', 'Россия'),
        ('KGP', 'Когалым', 'Когалым', 'Россия'),
        ('KJA', 'Емельяново', 'Красноярск', 'Россия'),
        ('KMW', 'Кострома', 'Кострома', 'Россия'),
        ('KRO', 'Курган', 'Курган', 'Россия'),
        ('KUF', 'Курумоч', 'Самара', 'Россия'),
        ('KVX', 'Киров', 'Киров', 'Россия'),
        ('KXK', 'Комсомольск-на-Амуре', 'Комсомольск-на-Амуре', 'Россия'),
        ('KYZ', 'Кызыл', 'Кызыл', 'Россия'),
        ('LDG', 'Лешуконское', 'Лешуконское', 'Россия'),
        ('LPK', 'Липецк', 'Липецк', 'Россия'),
        ('MCX', 'Махачкала', 'Махачкала', 'Россия'),
        ('MMK', 'Мурманск', 'Мурманск', 'Россия'),
        ('NJC', 'Нижневартовск', 'Нижневартовск', 'Россия'),
        ('NOJ', 'Ноябрьск', 'Ноябрьск', 'Россия'),
        ('NOZ', 'Новокузнецк', 'Новокузнецк', 'Россия'),
        ('NSK', 'Норильск', 'Норильск', 'Россия'),
        ('NVR', 'Новороссийск', 'Новороссийск', 'Россия'),
        # Международные (50 аэропортов)
        ('JFK', 'John F. Kennedy', 'Нью-Йорк', 'США'),
        ('LAX', 'Los Angeles International', 'Лос-Анджелес', 'США'),
        ('ORD', "O'Hare International", 'Чикаго', 'США'),
        ('ATL', 'Hartsfield-Jackson', 'Атланта', 'США'),
        ('DFW', 'Dallas/Fort Worth', 'Даллас', 'США'),
        ('MIA', 'Miami International', 'Майами', 'США'),
        ('LHR', 'Heathrow', 'Лондон', 'Великобритания'),
        ('LGW', 'Gatwick', 'Лондон', 'Великобритания'),
        ('CDG', 'Charles de Gaulle', 'Париж', 'Франция'),
        ('ORY', 'Orly', 'Париж', 'Франция'),
        ('FRA', 'Frankfurt am Main', 'Франкфурт', 'Германия'),
        ('MUC', 'Munich', 'Мюнхен', 'Германия'),
        ('AMS', 'Schiphol', 'Амстердам', 'Нидерланды'),
        ('IST', 'Istanbul Airport', 'Стамбул', 'Турция'),
        ('DXB', 'Dubai International', 'Дубай', 'ОАЭ'),
        ('HKG', 'Hong Kong International', 'Гонконг', 'Китай'),
        ('PEK', 'Beijing Capital', 'Пекин', 'Китай'),
        ('PVG', 'Shanghai Pudong', 'Шанхай', 'Китай'),
        ('NRT', 'Narita', 'Токио', 'Япония'),
        ('HND', 'Haneda', 'Токио', 'Япония'),
        ('SIN', 'Changi', 'Сингапур', 'Сингапур'),
        ('ICN', 'Incheon', 'Сеул', 'Южная Корея'),
        ('BKK', 'Suvarnabhumi', 'Бангкок', 'Таиланд'),
        ('SYD', 'Kingsford Smith', 'Сидней', 'Австралия'),
        ('MEL', 'Melbourne', 'Мельбурн', 'Австралия'),
        ('YYZ', 'Toronto Pearson', 'Торонто', 'Канада'),
        ('YVR', 'Vancouver', 'Ванкувер', 'Канада'),
        ('FCO', 'Fiumicino', 'Рим', 'Италия'),
        ('MXP', 'Malpensa', 'Милан', 'Италия'),
        ('MAD', 'Barajas', 'Мадрид', 'Испания'),
        ('BCN', 'El Prat', 'Барселона', 'Испания'),
        ('ZRH', 'Zurich', 'Цюрих', 'Швейцария'),
        ('VIE', 'Vienna', 'Вена', 'Австрия'),
        ('CPH', 'Kastrup', 'Копенгаген', 'Дания'),
        ('OSL', 'Gardermoen', 'Осло', 'Норвегия'),
        ('HEL', 'Helsinki-Vantaa', 'Хельсинки', 'Финляндия'),
        ('ARN', 'Arlanda', 'Стокгольм', 'Швеция'),
        ('DUB', 'Dublin', 'Дублин', 'Ирландия'),
        ('LIS', 'Lisbon', 'Лиссабон', 'Португалия'),
        ('ATH', 'Athens', 'Афины', 'Греция'),
        ('WAW', 'Chopin', 'Варшава', 'Польша'),
        ('PRG', 'Ruzyne', 'Прага', 'Чехия'),
        ('BUD', 'Ferenc Liszt', 'Будапешт', 'Венгрия'),
        ('OTP', 'Henri Coanda', 'Бухарест', 'Румыния'),
        ('SOF', 'Sofia', 'София', 'Болгария'),
        ('KBP', 'Boryspil', 'Киев', 'Украина'),
        ('TLV', 'Ben Gurion', 'Тель-Авив', 'Израиль'),
        ('CAI', 'Cairo International', 'Каир', 'Египет'),
        ('JNB', 'O.R. Tambo', 'Йоханнесбург', 'ЮАР'),
        ('BOM', 'Chhatrapati Shivaji', 'Мумбаи', 'Индия')
    ]
    
    used_iata_codes = set()
    airports_to_insert = []
    
    # Добавляем реальные аэропорты
    for iata, name, city, country in real_airports:
        airports_to_insert.append((iata, name, city, country))
        used_iata_codes.add(iata)
    
    # Генерируем дополнительные аэропорты до нужного количества
    while len(airports_to_insert) < NUM_RECORDS['airports']:
        while True:
            iata = ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ', k=3))
            if iata not in used_iata_codes:
                used_iata_codes.add(iata)
                break
        
        city = fake.city()
        country = 'Россия' if random.random() > 0.4 else random.choice([
            'США', 'Германия', 'Франция', 'Испания', 'Италия', 
            'Великобритания', 'Китай', 'Япония', 'Южная Корея',
            'Турция', 'ОАЭ', 'Канада', 'Австралия', 'Таиланд'
        ])
        name = f"Аэропорт {city}" if country == 'Россия' else f"{city} Airport"
        
        airports_to_insert.append((iata, name, city, country))
    
    cursor.executemany(
        "INSERT INTO airports (iata_code, name, city, country) VALUES (%s, %s, %s, %s)",
        airports_to_insert[:NUM_RECORDS['airports']]
    )
    
    conn.commit()
    cursor.close()
    print(f"✓ Добавлено {min(NUM_RECORDS['airports'], len(airports_to_insert))} аэропортов")

def generate_tariffs(conn):
    """Заполнение тарифов - короткие значения для included_luggage"""
    print("💰 Заполняем tariffs...")
    
    tariffs = [
        ('Эконом Баз', 3000.00, 0, '10 кг'),
        ('Эконом Станд', 5000.00, 1, '20 кг'),
        ('Эконом Гибкий', 8000.00, 1, '23 кг'),
        ('Премиум Эконом', 12000.00, 1, '25 кг'),
        ('Бизнес Баз', 25000.00, 1, '32 кг'),
        ('Бизнес Премиум', 35000.00, 1, '32 кг'),
        ('Первый класс', 60000.00, 1, '50 кг'),
        ('Промо', 2500.00, 0, '5 кг'),
        ('Молодёжный', 4000.00, 0, '15 кг'),
        ('Семейный', 4500.00, 1, '20 кг'),
        ('Корпоративный', 15000.00, 1, '30 кг'),
        ('Эконом Плюс', 6500.00, 1, '22 кг'),
        ('Бизнес Лайт', 22000.00, 1, '25 кг'),
        ('Супер-Эконом', 2800.00, 0, '8 кг'),
        ('Люкс', 75000.00, 1, '60 кг'),
        ('Бизнес Флекс', 28000.00, 1, '35 кг'),
        ('Эконом Про', 5500.00, 0, '18 кг'),
        ('Студенческий', 3500.00, 0, '15 кг'),
        ('Пенсионный', 3800.00, 0, '15 кг'),
        ('Групповой', 4200.00, 0, '20 кг')
    ]
    
    cursor = conn.cursor()
    
    # Выбираем нужное количество тарифов
    selected_tariffs = random.sample(tariffs, min(NUM_RECORDS['tariffs'], len(tariffs)))
    
    try:
        cursor.executemany(
            "INSERT INTO tariffs (name_of_tariff, base_value_of_tariff, possibility_of_return, included_luggage) VALUES (%s, %s, %s, %s)",
            selected_tariffs
        )
        conn.commit()
        print(f"✓ Добавлено {len(selected_tariffs)} тарифов")
    except mysql.connector.Error as e:
        print(f"❌ Ошибка при вставке тарифов: {e}")
        conn.rollback()
        raise
    
    cursor.close()

def generate_ticket_types(conn):
    """Заполнение типов билетов"""
    print("🎫 Заполняем ticket_type...")
    
    ticket_types = [
        ('ADULT', 'Взрослый', 12, 120, 0.0),
        ('CHILD', 'Ребенок (2-12)', 2, 12, 25.0),
        ('INFANT', 'Младенец (0-2)', 0, 2, 90.0),
        ('STUDENT', 'Студент', 12, 25, 20.0),
        ('YOUTH', 'Молодежь', 12, 18, 15.0),
        ('SENIOR', 'Пенсионер', 60, 120, 30.0),
        ('DISABLED', 'Инвалид', 0, 120, 40.0),
        ('INFANT_LAP', 'Младенец', 0, 2, 95.0),
        ('MILITARY', 'Военный', 18, 60, 25.0),
        ('FREQUENT', 'Частый летун', 18, 120, 10.0),
        ('VIP', 'VIP', 18, 120, 5.0),
        ('CREW', 'Экипаж', 18, 65, 100.0)
    ]
    
    cursor = conn.cursor()
    selected_types = random.sample(ticket_types, min(NUM_RECORDS['ticket_type'], len(ticket_types)))
    
    cursor.executemany(
        "INSERT INTO ticket_type (type_code, type_name, age_from, age_to, discount_percent) VALUES (%s, %s, %s, %s, %s)",
        selected_types
    )
    conn.commit()
    cursor.close()
    print(f"✓ Добавлено {len(selected_types)} типов билетов")

def generate_passengers(conn):
    """Упрощенная версия заполнения пассажиров"""
    print("👥 Заполняем passengers (упрощенно)...")
    
    cursor = conn.cursor()
    batch_size = 5000
    
    # Получаем ID типов документов
    cursor.execute("SELECT id_document_type, doc_type_cod FROM document_type")
    doc_types = cursor.fetchall()
    
    if not doc_types:
        print("❌ Нет типов документов!")
        return
    
    # Простое распределение по возрастам
    age_groups = [
        (0, 2, 0.05, 'BIRTH'),      # Младенцы
        (2, 12, 0.15, 'BIRTH'),     # Дети
        (12, 18, 0.15, 'PAS_RU'),   # Подростки
        (18, 30, 0.25, 'PAS_RU'),   # Молодежь
        (30, 60, 0.30, 'PAS_RU'),   # Взрослые
        (60, 100, 0.10, 'PAS_RU')   # Пожилые
    ]
    
    total_inserted = 0
    batch_number = 0
    
    # Создаем временный набор для отслеживания уникальности
    used_passports = set()
    
    while total_inserted < NUM_RECORDS['passengers']:
        batch = []
        remaining = NUM_RECORDS['passengers'] - total_inserted
        current_batch_size = min(batch_size, remaining)
        
        for _ in range(current_batch_size):
            # Выбираем возрастную группу
            rand = random.random()
            cumulative = 0
            selected_group = None
            
            for group in age_groups:
                cumulative += group[2]
                if rand <= cumulative:
                    selected_group = group
                    break
            
            if not selected_group:
                selected_group = age_groups[3]  # По умолчанию молодежь
            
            min_age, max_age, _, doc_code = selected_group
            
            # Находим ID типа документа
            doc_type_id = next((doc_id for doc_id, code in doc_types if code == doc_code), doc_types[0][0])
            
            # Генерируем дату рождения
            birth_date = fake.date_of_birth(minimum_age=min_age, maximum_age=max_age)
            
            # Генерируем уникальный номер паспорта
            while True:
                if doc_code == 'BIRTH':
                    passport = f"РН-{random.randint(100000, 999999)}"
                else:
                    # Паспорт РФ: серия номер
                    passport = f"{random.randint(10, 99)} {random.randint(100000, 999999)}"
                
                passport_key = f"{passport}-{doc_type_id}"
                if passport_key not in used_passports:
                    used_passports.add(passport_key)
                    break
            
            # Телефон и email
            phone = f"+7{random.randint(900, 999)}{random.randint(1000000, 9999999)}"
            name = fake.name()
            email = fake.email()
            
            batch.append((
                name,
                passport,
                birth_date,
                email,
                phone,
                doc_type_id
            ))
        
        try:
            cursor.executemany(
                "INSERT INTO passengers (fio_passenger, passport_number, date_of_birth, email_passenger, phone_of_passenger, document_type_id_document_type) VALUES (%s, %s, %s, %s, %s, %s)",
                batch
            )
            conn.commit()
            total_inserted += len(batch)
            batch_number += 1
            
            if batch_number % 5 == 0:
                print(f"  Прогресс: {total_inserted:,}/{NUM_RECORDS['passengers']:,}")
                
        except Exception as e:
            print(f"  Ошибка: {e}")
            conn.rollback()
            # Пробуем вставить по одной
            for passenger in batch:
                try:
                    cursor.execute(
                        "INSERT INTO passengers (fio_passenger, passport_number, date_of_birth, email_passenger, phone_of_passenger, document_type_id_document_type) VALUES (%s, %s, %s, %s, %s, %s)",
                        passenger
                    )
                    conn.commit()
                    total_inserted += 1
                except:
                    pass
    
    cursor.close()
    print(f"✓ Добавлено {total_inserted:,} пассажиров")

def generate_seat_maps(conn):
    """Заполнение карт мест - 200 КАРТ"""
    print("🗺️ Заполняем seat_maps...")
    
    cursor = conn.cursor()
    
    # Получаем все самолеты
    cursor.execute("SELECT id_aircraft, number_of_seats FROM aircrafts")
    aircrafts = cursor.fetchall()
    
    seat_maps_data = []
    aircrafts_used = set()  # Для отслеживания уже использованных самолетов
    
    # Создаем по одной карте на каждый самолет
    for aircraft_id, total_seats in aircrafts:
        # Пропускаем если уже создали карту для этого самолета
        if aircraft_id in aircrafts_used:
            continue
            
        aircrafts_used.add(aircraft_id)
        
        # Определяем конфигурацию мест на основе количества мест
        if total_seats < 100:
            rows = random.randint(15, 25)
            cols = random.choice([4, 6])
            business_rows = random.randint(0, 2)
        elif total_seats < 200:
            rows = random.randint(25, 35)
            cols = random.choice([6, 8])
            business_rows = random.randint(2, 6)
        elif total_seats < 300:
            rows = random.randint(35, 45)
            cols = random.choice([8, 9])
            business_rows = random.randint(4, 8)
        elif total_seats < 400:
            rows = random.randint(40, 55)
            cols = random.choice([9, 10])
            business_rows = random.randint(6, 10)
        else:
            rows = random.randint(50, 65)
            cols = random.choice([9, 10])
            business_rows = random.randint(8, 12)
        
        # Добавляем небольшие вариации
        rows += random.randint(-3, 3)
        business_rows += random.randint(-1, 1)
        business_rows = max(0, business_rows)
        
        # Убедимся, что общее количество мест примерно соответствует самолету
        total_seats_in_map = rows * cols
        while abs(total_seats_in_map - total_seats) > total_seats * 0.3:  # Разница не более 30%
            if total_seats_in_map < total_seats:
                rows += 1
            else:
                rows -= 1
            total_seats_in_map = rows * cols
        
        seat_maps_data.append((
            f"Карта для {aircraft_id}",
            rows,
            cols,
            business_rows,
            aircraft_id
        ))
        
        # Останавливаемся когда достигнем нужного количества карт
        if len(seat_maps_data) >= NUM_RECORDS['seat_maps']:
            break
    
    # Если нужно больше карт чем самолетов, создаем дополнительные для уже существующих самолетов
    # с разными конфигурациями (но это нарушит ограничение уникальности)
    # Поэтому лучше изменить количество карт или удалить ограничение UNIQUE
    
    if len(seat_maps_data) < NUM_RECORDS['seat_maps']:
        print(f"  ⚠️ Можно создать только {len(seat_maps_data)} карт (по одной на самолет)")
        print(f"  Измените NUM_RECORDS['seat_maps'] на {len(seat_maps_data)} или удалите ограничение UNIQUE")
        # Можно либо остановиться здесь, либо пропустить лишние карты
    
    # Ограничиваем количество (если самолетов меньше чем нужно карт)
    seat_maps_data = seat_maps_data[:min(NUM_RECORDS['seat_maps'], len(seat_maps_data))]
    
    try:
        cursor.executemany(
            "INSERT INTO seat_maps (schema_name, rows_count, columns_count, business_class_rows, aircrafts_id_aircraft) VALUES (%s, %s, %s, %s, %s)",
            seat_maps_data
        )
        conn.commit()
        cursor.close()
        print(f"✓ Добавлено {len(seat_maps_data)} карт мест")
        
    except mysql.connector.IntegrityError as e:
        print(f"❌ Ошибка уникальности: {e}")
        print("  Проблема: ограничение UNIQUE на aircrafts_id_aircraft")
        print("  Решения:")
        print("  1. Удалите ограничение UNIQUE из таблицы seat_maps")
        print("  2. Уменьшите NUM_RECORDS['seat_maps'] до количества самолетов")
        print("  3. Создайте альтернативные конфигурации для существующих самолетов")
        conn.rollback()
        raise

def generate_seats(conn):
    """Заполнение мест - 80,000 МЕСТ"""
    print("💺 Заполняем seats...")
    
    cursor = conn.cursor()
    batch_size = 5000
    
    cursor.execute("SELECT id_maps, rows_count, columns_count, business_class_rows FROM seat_maps")
    seat_maps = cursor.fetchall()
    
    total_seats = 0
    seats_batch = []
    seat_counter = 0
    
    for seat_map_id, rows_count, cols_count, business_rows in seat_maps:
        for row in range(1, rows_count + 1):
            if row <= business_rows:
                seat_class = 'BUSINESS'
                seat_type_prob = random.random()
                if seat_type_prob < 0.4:
                    seat_type = 'WINDOW'
                elif seat_type_prob < 0.8:
                    seat_type = 'AISLE'
                else:
                    seat_type = 'EXTRA_LEGROOM'
            else:
                seat_class = 'ECONOMY'
                seat_type_prob = random.random()
                if seat_type_prob < 0.3:
                    seat_type = 'WINDOW'
                elif seat_type_prob < 0.6:
                    seat_type = 'MIDDLE'
                else:
                    seat_type = 'AISLE'
            
            for col in range(1, cols_count + 1):
                # Пропускаем места для проходов (примерно каждый 4-й столбец)
                if col % 4 == 0 and col != cols_count:
                    continue
                
                seat_letter = chr(64 + col)
                seat_number = f"{row}{seat_letter}"
                
                seats_batch.append((
                    seat_number, row, seat_letter, seat_class, seat_type, seat_map_id
                ))
                total_seats += 1
                seat_counter += 1
                
                # Вставляем пачками
                if len(seats_batch) >= batch_size or seat_counter >= NUM_RECORDS['seats']:
                    cursor.executemany(
                        "INSERT INTO seats (seat_number, seat_row, seat_letter, seat_class, seat_type, seat_maps_id_maps) VALUES (%s, %s, %s, %s, %s, %s)",
                        seats_batch
                    )
                    conn.commit()
                    seats_batch = []
                    
                    if seat_counter % 20000 == 0:
                        print(f"  Сгенерировано: {seat_counter:,}/{NUM_RECORDS['seats']:,}")
                
                if seat_counter >= NUM_RECORDS['seats']:
                    break
            
            if seat_counter >= NUM_RECORDS['seats']:
                break
        
        if seat_counter >= NUM_RECORDS['seats']:
            break
    
    if seats_batch:
        cursor.executemany(
            "INSERT INTO seats (seat_number, seat_row, seat_letter, seat_class, seat_type, seat_maps_id_maps) VALUES (%s, %s, %s, %s, %s, %s)",
            seats_batch
        )
        conn.commit()
    
    cursor.close()
    print(f"✓ Добавлено {seat_counter:,} мест")

def generate_flights(conn):
    """Заполнение рейсов - 5,000 РЕЙСОВ!"""
    print("🛫 Заполняем flights...")
    
    cursor = conn.cursor()
    batch_size = 1000
    
    cursor.execute("SELECT id_aircraft FROM aircrafts")
    aircraft_ids = [row[0] for row in cursor.fetchall()]
    
    cursor.execute("SELECT id_airport, iata_code FROM airports")
    airports = cursor.fetchall()
    
    airlines = ['SU', 'S7', 'U6', 'DP', '5N', 'N4', 'FV', 'UT', 'WZ', 'D2', '6W', 'B2', 'BT', 'TK', 'LH', 'AF', 'BA', 'AA', 'DL', 'UA', 'EK', 'QR']
    
    total_inserted = 0
    batch_number = 0
    
    while total_inserted < NUM_RECORDS['flights']:
        batch = []
        remaining = NUM_RECORDS['flights'] - total_inserted
        current_batch_size = min(batch_size, remaining)
        
        for _ in range(current_batch_size):
            dep_airport_id, dep_iata = random.choice(airports)
            arr_airport = random.choice([a for a in airports if a[0] != dep_airport_id])
            arr_airport_id, arr_iata = arr_airport
            
            # Дата вылета (от 30 дней назад до 365 дней вперед)
            departure = datetime.now() - timedelta(days=random.randint(0, 30))
            departure += timedelta(days=random.randint(0, 365))
            
            # Время полета (1-14 часов)
            duration = timedelta(hours=random.randint(1, 14))
            arrival = departure + duration
            
            # Номер рейса
            airline = random.choice(airlines)
            flight_num = f"{airline} {random.randint(100, 9999)}"
            
            # Статус рейса с реалистичным распределением
            status_prob = random.random()
            if departure > datetime.now() + timedelta(days=7):
                status = 'SCHEDULED'
            elif departure > datetime.now():
                status = 'BOARDING'
            elif departure <= datetime.now() < arrival:
                status = 'DEPARTED'
            elif arrival <= datetime.now():
                status = 'ARRIVED'
            else:
                status = random.choice(['CANCELLED', 'DELAYED'])
            
            batch.append((
                flight_num,
                departure,
                arrival,
                status,
                dep_airport_id,
                arr_airport_id,
                random.choice(aircraft_ids)
            ))
        
        cursor.executemany(
            "INSERT INTO flights (number_of_flight, date_time_of_departure, date_time_of_arrival, status_of_flights, airports_id_airport2, airports_id_airport, aircrafts_id_aircraft) VALUES (%s, %s, %s, %s, %s, %s, %s)",
            batch
        )
        conn.commit()
        total_inserted += len(batch)
        batch_number += 1
        
        if batch_number % 5 == 0:
            print(f"  Прогресс: {total_inserted:,}/{NUM_RECORDS['flights']:,}")
    
    cursor.close()
    print(f"✓ Добавлено {total_inserted:,} рейсов")

def generate_seats_on_flight(conn):
    """Заполнение мест на рейсах - 300,000 МЕСТ"""
    print("🔄 Заполняем seats_on_flight...")
    
    cursor = conn.cursor()
    batch_size = 10000
    
    cursor.execute("SELECT id_flight, aircrafts_id_aircraft FROM flights")
    flights = cursor.fetchall()
    
    print(f"  Всего рейсов: {len(flights):,}")
    
    if not flights:
        print("⚠️ Нет рейсов!")
        return
    
    # Загружаем места по самолетам
    cursor.execute("""
        SELECT sm.aircrafts_id_aircraft, s.id_seat, s.seat_class 
        FROM seat_maps sm
        JOIN seats s ON sm.id_maps = s.seat_maps_id_maps
    """)
    
    aircraft_seats = {}
    for aircraft_id, seat_id, seat_class in cursor.fetchall():
        if aircraft_id not in aircraft_seats:
            aircraft_seats[aircraft_id] = []
        aircraft_seats[aircraft_id].append((seat_id, seat_class))
    
    # Рассчитываем сколько мест на рейс в среднем
    seats_per_flight = NUM_RECORDS['seats_on_flight'] // len(flights)
    seats_per_flight = max(50, min(seats_per_flight, 350))
    print(f"  По {seats_per_flight} мест на рейс в среднем")
    
    total_generated = 0
    seats_batch = []
    batch_counter = 0
    
    for flight_id, aircraft_id in flights:
        if total_generated >= NUM_RECORDS['seats_on_flight']:
            break
        
        if aircraft_id not in aircraft_seats:
            continue
        
        available_seats = aircraft_seats[aircraft_id]
        if len(available_seats) == 0:
            continue
        
        # Определяем сколько мест на этот рейс
        seats_to_take = min(
            len(available_seats),
            random.randint(int(seats_per_flight * 0.6), int(seats_per_flight * 1.0))
        )
        
        selected_seats = random.sample(available_seats, min(seats_to_take, len(available_seats)))
        
        for seat_id, seat_class in selected_seats:
            if total_generated >= NUM_RECORDS['seats_on_flight']:
                break
            
            # Цена в зависимости от класса
            if seat_class == 'BUSINESS':
                base_price = random.randint(20000, 150000)
            else:
                base_price = random.randint(5000, 50000)
            
            # Динамическое ценообразование
            price_multiplier = random.uniform(0.7, 1.5)
            current_price = round(base_price * price_multiplier, 2)
            
            # Статус места (некоторые уже заняты)
            if random.random() < 0.3:  # 30% мест уже заняты
                is_available = 'N'
                seat_status = 'booked'
            else:
                is_available = 'Y'
                seat_status = 'free'
            
            seats_batch.append((
                is_available,
                current_price,
                seat_status,
                flight_id,
                seat_id
            ))
            total_generated += 1
            
            # Вставляем пачками
            if len(seats_batch) >= batch_size:
                batch_counter += 1
                cursor.executemany(
                    "INSERT INTO seats_on_flight (is_available, current_price, seat_status, flights_id_flight, seats_id_seat) VALUES (%s, %s, %s, %s, %s)",
                    seats_batch
                )
                conn.commit()
                seats_batch = []
                if batch_counter % 5 == 0:
                    print(f"  Сгенерировано: {total_generated:,}/{NUM_RECORDS['seats_on_flight']:,}")
    
    if seats_batch:
        cursor.executemany(
            "INSERT INTO seats_on_flight (is_available, current_price, seat_status, flights_id_flight, seats_id_seat) VALUES (%s, %s, %s, %s, %s)",
            seats_batch
        )
        conn.commit()
    
    cursor.close()
    print(f"✓ Добавлено {total_generated:,} мест на рейсах")

def generate_bookings(conn):
    """Заполнение бронирований - с правильной проверкой возраста"""
    print("📅 Заполняем bookings...")
    
    cursor = conn.cursor()
    
    # Сначала получим все необходимые данные
    print("  Получаем данные для бронирований...")
    
    # 1. Получаем пассажиров с вычислением их возраста на случайную дату
    cursor.execute("""
        SELECT 
            id_passenger,
            date_of_birth
        FROM passengers
        ORDER BY RAND()
        LIMIT 100000
    """)
    passengers = cursor.fetchall()
    print(f"  • Загружено пассажиров: {len(passengers):,}")
    
    # 2. Получаем типы билетов
    cursor.execute("SELECT id_ticket_type, age_from, age_to FROM ticket_type ORDER BY age_from")
    ticket_types = cursor.fetchall()
    print(f"  • Загружено типов билетов: {len(ticket_types)}")
    
    # Создаем структуру для быстрого поиска категории по возрасту
    age_to_ticket_types = {}
    for age in range(0, 121):
        matching_types = []
        for type_id, age_from, age_to in ticket_types:
            if age_from <= age <= age_to:
                matching_types.append(type_id)
        age_to_ticket_types[age] = matching_types
    
    # 3. Получаем тарифы
    cursor.execute("SELECT id_tariff FROM tariffs")
    tariffs = [row[0] for row in cursor.fetchall()]
    print(f"  • Загружено тарифов: {len(tariffs)}")
    
    # 4. Получаем свободные места
    cursor.execute("""
        SELECT 
            sof.id_seat_on_flight, 
            sof.current_price,
            f.date_time_of_departure
        FROM seats_on_flight sof
        JOIN flights f ON sof.flights_id_flight = f.id_flight
        WHERE sof.is_available = 'Y'
        ORDER BY RAND()
        LIMIT 200000
    """)
    seats = cursor.fetchall()
    print(f"  • Загружено свободных мест: {len(seats):,}")
    
    if len(seats) < 10000:
        print("⚠️ Слишком мало свободных мест!")
        cursor.close()
        return
    
    # 5. Генерируем бронирования
    print("  Генерируем бронирования...")
    
    total_generated = 0
    batch_size = 1000
    seats_used = set()
    
    # Создаем тестовые данные для отладки
    test_data = []
    for i in range(min(100, len(passengers))):
        passenger_id, date_of_birth = passengers[i]
        
        # Создаем случайную дату бронирования (в прошлом)
        booking_date = datetime.now() - timedelta(days=random.randint(1, 365))
        
        # Вычисляем возраст на момент бронирования (точно как в триггере)
        age_at_booking = booking_date.year - date_of_birth.year
        if (booking_date.month, booking_date.day) < (date_of_birth.month, date_of_birth.day):
            age_at_booking -= 1
        
        # Находим подходящую категорию
        matching_types = age_to_ticket_types.get(age_at_booking, [])
        if matching_types:
            ticket_type_id = random.choice(matching_types)
        else:
            # Используем категорию для взрослых по умолчанию
            cursor.execute("SELECT id_ticket_type FROM ticket_type WHERE type_code = 'ADULT' LIMIT 1")
            adult_ticket = cursor.fetchone()
            ticket_type_id = adult_ticket[0] if adult_ticket else ticket_types[0][0]
        
        test_data.append({
            'passenger_id': passenger_id,
            'date_of_birth': date_of_birth,
            'booking_date': booking_date,
            'age_at_booking': age_at_booking,
            'ticket_type_id': ticket_type_id
        })
    
    print(f"  • Протестировано {len(test_data)} комбинаций возраста и категорий")
    
    # Основной цикл генерации
    batch_number = 0
    failed_due_to_age = 0
    
    while total_generated < NUM_RECORDS['bookings'] and len(seats) > 0:
        batch = []
        remaining = NUM_RECORDS['bookings'] - total_generated
        current_batch_size = min(batch_size, remaining, len(seats))
        
        for i in range(current_batch_size):
            if not seats:
                break
            
            # Берем следующее свободное место
            seat_id, seat_price, flight_date = seats.pop(0)
            
            # Выбираем случайного пассажира
            passenger_id, date_of_birth = random.choice(passengers)
            
            # Дата бронирования должна быть ДО даты вылета
            # Генерируем дату бронирования от 1 дня до 90 дней до вылета
            days_before_flight = random.randint(1, 90)
            booking_date = flight_date - timedelta(days=days_before_flight, 
                                                  hours=random.randint(0, 23),
                                                  minutes=random.randint(0, 59))
            
            # Вычисляем возраст на момент бронирования (точно как в триггере!)
            age_at_booking = booking_date.year - date_of_birth.year
            if (booking_date.month, booking_date.day) < (date_of_birth.month, date_of_birth.day):
                age_at_booking -= 1
            
            # Находим подходящую категорию билета
            matching_types = age_to_ticket_types.get(age_at_booking, [])
            
            if not matching_types:
                failed_due_to_age += 1
                # Пропускаем этого пассажира
                seats.insert(0, (seat_id, seat_price, flight_date))  # Возвращаем место
                continue
            
            ticket_type_id = random.choice(matching_types)
            
            # Получаем скидку для этой категории
            cursor.execute("SELECT discount_percent FROM ticket_type WHERE id_ticket_type = %s", (ticket_type_id,))
            discount = cursor.fetchone()[0]
            
            # Рассчитываем сумму
            total_amount = round(seat_price * (1 - discount / 100), 2)
            
            # Время истечения брони (15 минут - 24 часа)
            expiration_date = booking_date + timedelta(minutes=random.randint(15, 1440))
            
            # Статус брони
            status_chance = random.random()
            if status_chance < 0.6:
                status = 'CONFIRMED'
            elif status_chance < 0.85:
                status = 'PENDING'
            else:
                status = 'CANCELLED'
            
            # Добавляем в пакет
            batch.append((
                booking_date,
                status,
                expiration_date,
                total_amount,
                passenger_id,
                random.choice(tariffs),
                seat_id,
                ticket_type_id
            ))
            total_generated += 1
        
        if not batch:
            continue
        
        # Вставляем пакет
        try:
            cursor.executemany(
                """INSERT INTO bookings 
                   (datetime_of_booking, status, datetime_expiration, total_amount, 
                    passengers_id_passenger, tariffs_id_tariff, seats_on_flight_id_seats, 
                    ticket_type_id_ticket_type) 
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
                batch
            )
            conn.commit()
            batch_number += 1
            
            if batch_number % 10 == 0 or total_generated % 10000 == 0:
                print(f"  Прогресс: {total_generated:,}/{NUM_RECORDS['bookings']:,}")
                
        except mysql.connector.Error as e:
            if "check_passenger_age_before_booking" in str(e):
                print(f"  ⚠️ Ошибка триггера возраста в пакете {batch_number}")
                conn.rollback()
                
                # Отладочная информация
                print(f"  Отладка: проверяем проблемные записи...")
                for idx, booking in enumerate(batch[:5]):  # Проверяем первые 5
                    booking_date, status, expiration_date, total_amount, passenger_id, tariff_id, seat_id, ticket_type_id = booking
                    
                    # Получаем дату рождения пассажира
                    cursor.execute("SELECT date_of_birth FROM passengers WHERE id_passenger = %s", (passenger_id,))
                    dob_result = cursor.fetchone()
                    if dob_result:
                        dob = dob_result[0]
                        # Вычисляем возраст как в триггере
                        age = booking_date.year - dob.year
                        if (booking_date.month, booking_date.day) < (dob.month, dob.day):
                            age -= 1
                        
                        # Проверяем категорию
                        cursor.execute("SELECT age_from, age_to FROM ticket_type WHERE id_ticket_type = %s", (ticket_type_id,))
                        type_result = cursor.fetchone()
                        if type_result:
                            age_from, age_to = type_result
                            print(f"    Запись {idx}: возраст {age}, категория {ticket_type_id} ({age_from}-{age_to}) - {'OK' if age_from <= age <= age_to else 'ERROR'}")
                
                # Пробуем вставить по одной
                successful = 0
                for booking in batch:
                    try:
                        cursor.execute(
                            """INSERT INTO bookings 
                               (datetime_of_booking, status, datetime_expiration, total_amount, 
                                passengers_id_passenger, tariffs_id_tariff, seats_on_flight_id_seats, 
                                ticket_type_id_ticket_type) 
                               VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
                            booking
                        )
                        conn.commit()
                        successful += 1
                    except:
                        conn.rollback()
                
                print(f"    Вставлено {successful} из {len(batch)} записей")
                total_generated = total_generated - len(batch) + successful
                
            else:
                print(f"  ⚠️ Другая ошибка: {e}")
                conn.rollback()
    
    if failed_due_to_age > 0:
        print(f"  ⚠️ Пропущено {failed_due_to_age} бронирований из-за несоответствия возраста")
    
    # Обновляем статистику
    cursor.execute("SELECT COUNT(*) FROM bookings")
    final_count = cursor.fetchone()[0]
    
    cursor.close()
    print(f"✓ Добавлено {final_count:,} бронирований")
    return final_count

def generate_payments(conn):
    """Заполнение платежей - НЕ ВСЕ БРОНИ ОПЛАЧЕНЫ"""
    print("💳 Заполняем payments...")
    
    cursor = conn.cursor()
    batch_size = 15000
    
    # Получаем подтвержденные брони без платежей
    print("  Получаем подтвержденные брони для оплаты...")
    cursor.execute("""
        SELECT b.id_booking, b.total_amount, b.datetime_of_booking 
        FROM bookings b 
        WHERE b.status = 'CONFIRMED' 
        AND b.id_booking NOT IN (SELECT bookings_id_booking FROM payments)
        ORDER BY RAND()
        LIMIT %s
    """, (NUM_RECORDS['payments'] * 2,))
    
    bookings = cursor.fetchall()
    
    print(f"  Найдено подтвержденных броней для оплаты: {len(bookings):,}")
    
    if len(bookings) < NUM_RECORDS['payments']:
        print(f"⚠️ Подтвержденных броней меньше ({len(bookings):,}). Используем все брони.")
        cursor.execute("""
            SELECT b.id_booking, b.total_amount, b.datetime_of_booking 
            FROM bookings b 
            WHERE b.id_booking NOT IN (SELECT bookings_id_booking FROM payments)
            AND b.status IN ('CONFIRMED', 'PENDING')
            ORDER BY RAND()
            LIMIT %s
        """, (NUM_RECORDS['payments'],))
        bookings = cursor.fetchall()
    
    # Выбираем случайные брони для оплаты (не все!)
    payments_to_generate = min(NUM_RECORDS['payments'], len(bookings))
    bookings_to_pay = random.sample(bookings, payments_to_generate)
    
    payment_stats = {
        'SUCCESS': 0,
        'FAILED': 0,
        'PENDING': 0
    }
    
    batch_counter = 0
    total_generated = 0
    
    for i in range(0, len(bookings_to_pay), batch_size):
        batch = []
        end_idx = min(i + batch_size, len(bookings_to_pay))
        
        for booking_id, amount, booking_time in bookings_to_pay[i:end_idx]:
            # Преобразуем decimal.Decimal в float для вычислений
            amount_float = float(amount)
            
            # Время платежа (от 0 до 3 дней после бронирования)
            payment_time = booking_time + timedelta(
                days=random.randint(0, 3),
                hours=random.randint(0, 23),
                minutes=random.randint(0, 59)
            )
            
            # Статус платежа
            status_prob = random.random()
            if status_prob < 0.95:  # 95% успешных
                status = 'SUCCESS'
                error_code = None
                payment_amount = amount_float * random.uniform(0.98, 1.02)  # ±2%
                payment_amount = round(payment_amount, 2)
                payment_stats['SUCCESS'] += 1
            elif status_prob < 0.98:  # 3% неудачных
                status = 'FAILED'
                error_codes = [
                    'INSUFFICIENT_FUNDS', 'CARD_DECLINED', 'TIMEOUT',
                    'FRAUD_DETECTED', 'INVALID_CARD', 'LIMIT_EXCEEDED',
                    'BANK_REJECTED', 'NETWORK_ERROR', '3DS_FAILED'
                ]
                error_code = random.choice(error_codes)
                payment_amount = amount_float
                payment_stats['FAILED'] += 1
            else:  # 2% ожидающих
                status = 'PENDING'
                error_code = None
                payment_amount = amount_float
                payment_stats['PENDING'] += 1
            
            batch.append((payment_amount, status, payment_time, error_code, booking_id))
            total_generated += 1
        
        try:
            cursor.executemany(
                "INSERT INTO payments (amount, payment_status, payment_date, error_code, bookings_id_booking) VALUES (%s, %s, %s, %s, %s)",
                batch
            )
            conn.commit()
            batch_counter += 1
            
            if batch_counter % 10 == 0 or total_generated % 50000 == 0:
                print(f"  Прогресс: {total_generated:,}/{payments_to_generate:,} (пакет {batch_counter})")
                
        except Exception as e:
            print(f"  ⚠️ Ошибка при вставке платежей: {e}")
            conn.rollback()
            # Попробуем вставить по одному
            successful_in_batch = 0
            for payment in batch:
                try:
                    cursor.execute(
                        "INSERT INTO payments (amount, payment_status, payment_date, error_code, bookings_id_booking) VALUES (%s, %s, %s, %s, %s)",
                        payment
                    )
                    conn.commit()
                    successful_in_batch += 1
                except:
                    conn.rollback()
            print(f"    Вставлено {successful_in_batch} из {len(batch)} платежей из проблемного пакета")
    
    # Статистика платежей
    total_payments = sum(payment_stats.values())
    print(f"\n  Статистика платежей:")
    print(f"    • SUCCESS: {payment_stats['SUCCESS']:,} ({payment_stats['SUCCESS']/total_payments*100:.1f}%)")
    print(f"    • FAILED: {payment_stats['FAILED']:,} ({payment_stats['FAILED']/total_payments*100:.1f}%)")
    print(f"    • PENDING: {payment_stats['PENDING']:,} ({payment_stats['PENDING']/total_payments*100:.1f}%)")
    
    # Брони без платежей
    cursor.execute("""
        SELECT COUNT(*) 
        FROM bookings b 
        WHERE b.status = 'CONFIRMED' 
        AND b.id_booking NOT IN (SELECT bookings_id_booking FROM payments)
    """)
    unpaid_confirmed = cursor.fetchone()[0]
    print(f"    • Подтвержденных броней без платежей: {unpaid_confirmed:,}")
    
    # Общая статистика
    cursor.execute("SELECT COUNT(*) FROM payments")
    total_in_table = cursor.fetchone()[0]
    print(f"    • Всего платежей в таблице: {total_in_table:,}")
    
    cursor.close()
    print(f"✓ Добавлено {total_in_table:,} платежей")

def update_seat_availability(conn):
    """Обновляем статусы мест на основе бронирований"""
    print("🔄 Обновляем статусы мест...")
    
    cursor = conn.cursor()
    
    print("  Обновляем статусы для подтвержденных броней...")
    cursor.execute("""
        UPDATE seats_on_flight sof
        INNER JOIN bookings b ON sof.id_seat_on_flight = b.seats_on_flight_id_seats
        SET sof.is_available = 'N', sof.seat_status = 'booked'
        WHERE b.status = 'CONFIRMED'
    """)
    
    updated_confirmed = cursor.rowcount
    print(f"    • Обновлено мест для подтвержденных броней: {updated_confirmed:,}")
    
    print("  Обновляем статусы для броней в ожидании...")
    cursor.execute("""
        UPDATE seats_on_flight sof
        INNER JOIN bookings b ON sof.id_seat_on_flight = b.seats_on_flight_id_seats
        SET sof.is_available = 'N', sof.seat_status = 'blocked'
        WHERE b.status = 'PENDING'
    """)
    
    updated_pending = cursor.rowcount
    print(f"    • Обновлено мест для броней в ожидании: {updated_pending:,}")
    
    print("  Освобождаем места для отмененных броней...")
    cursor.execute("""
        UPDATE seats_on_flight sof
        INNER JOIN bookings b ON sof.id_seat_on_flight = b.seats_on_flight_id_seats
        SET sof.is_available = 'Y', sof.seat_status = 'free'
        WHERE b.status = 'CANCELLED'
    """)
    
    updated_cancelled = cursor.rowcount
    print(f"    • Освобождено мест для отмененных броней: {updated_cancelled:,}")
    
    conn.commit()
    
    # Статистика мест
    cursor.execute("""
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN is_available = 'Y' THEN 1 ELSE 0 END) as available,
            SUM(CASE WHEN is_available = 'N' THEN 1 ELSE 0 END) as occupied,
            SUM(CASE WHEN seat_status = 'free' THEN 1 ELSE 0 END) as free,
            SUM(CASE WHEN seat_status = 'booked' THEN 1 ELSE 0 END) as booked,
            SUM(CASE WHEN seat_status = 'blocked' THEN 1 ELSE 0 END) as blocked
        FROM seats_on_flight
    """)
    stats = cursor.fetchone()
    
    print(f"\n  Итоговая статистика мест:")
    print(f"    • Всего мест: {stats[0]:,}")
    print(f"    • Свободно: {stats[1]:,} ({stats[1]/stats[0]*100:.1f}%)")
    print(f"    • Занято: {stats[2]:,} ({stats[2]/stats[0]*100:.1f}%)")
    print(f"    • Статус free: {stats[3]:,}")
    print(f"    • Статус booked: {stats[4]:,}")
    print(f"    • Статус blocked: {stats[5]:,}")
    
    cursor.close()
    print("✓ Статусы мест обновлены")

def verify_ticket_type_coverage(conn):
    """Проверяем, что все возраста покрыты типами билетов"""
    print("🔍 Проверка покрытия возрастов типами билетов...")
    
    cursor = conn.cursor()
    
    # Получаем диапазоны возрастов из ticket_type
    cursor.execute("SELECT age_from, age_to FROM ticket_type ORDER BY age_from")
    ranges = cursor.fetchall()
    
    # Проверяем покрытие от 0 до 120 лет
    all_covered = True
    missing_ages = []
    
    for age in range(0, 121):
        covered = False
        for age_from, age_to in ranges:
            if age_from <= age <= age_to:
                covered = True
                break
        
        if not covered:
            all_covered = False
            missing_ages.append(age)
    
    if all_covered:
        print("  ✓ Все возраста от 0 до 120 лет покрыты типами билетов")
    else:
        print(f"  ⚠️ Не покрыты возрасты: {missing_ages[:10]}{'...' if len(missing_ages) > 10 else ''}")
        print(f"  Всего непокрытых возрастов: {len(missing_ages)}")
    
    # Проверяем пассажиров без покрытия
    cursor.execute("""
        SELECT COUNT(*) as uncovered_passengers
        FROM passengers p
        WHERE NOT EXISTS (
            SELECT 1 FROM ticket_type tt
            WHERE TIMESTAMPDIFF(YEAR, p.date_of_birth, CURDATE()) BETWEEN tt.age_from AND tt.age_to
        )
    """)
    uncovered_passengers = cursor.fetchone()[0]
    print(f"  Пассажиров без покрытия категориями: {uncovered_passengers:,}")
    
    cursor.close()
    return all_covered

def create_triggers_and_indexes(conn):
    """Создаем только триггеры, индексы уже есть в SQL"""
    print("⚡ Создаем триггеры...")
    
    cursor = conn.cursor()
    
    # 1. Удаляем старый триггер если есть
    try:
        cursor.execute("DROP TRIGGER IF EXISTS check_passenger_age_before_booking")
        print("  ✓ Удалили старый триггер")
    except:
        pass
    
    # 2. Создаем триггер проверки возраста (ТОЧНО КАК В ВАШЕМ SQL)
    print("  Создаем триггер проверки возраста...")
    trigger_sql = """
    CREATE TRIGGER check_passenger_age_before_booking
    BEFORE INSERT ON bookings
    FOR EACH ROW
    BEGIN
        DECLARE passenger_age INT;
        DECLARE valid_category BOOLEAN;
        
        -- Вычисляем возраст пассажира на момент бронирования
        SELECT TIMESTAMPDIFF(YEAR, p.date_of_birth, NEW.datetime_of_booking) 
        INTO passenger_age
        FROM passengers p 
        WHERE p.id_passenger = NEW.passengers_id_passenger;
        
        -- Проверяем соответствие категории
        SELECT COUNT(*) INTO valid_category
        FROM ticket_type tt
        WHERE tt.id_ticket_type = NEW.ticket_type_id_ticket_type
          AND passenger_age BETWEEN tt.age_from AND tt.age_to;
        
        IF valid_category = 0 THEN
            SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'Ошибка: Возраст пассажира не соответствует выбранной категории билета';
        END IF;
    END
    """
    
    try:
        cursor.execute(trigger_sql)
        conn.commit()
        print("    ✓ Триггер проверки возраста создан")
    except Exception as e:
        print(f"    ⚠️ Не удалось создать триггер: {e}")
        conn.rollback()
    
    cursor.close()
    print("✅ Триггеры созданы")

def print_final_statistics(conn):
    """Вывод финальной статистики"""
    print("\n" + "="*70)
    print("📊 ФИНАЛЬНАЯ СТАТИСТИКА БАЗЫ ДАННЫХ")
    print("="*70)
    
    cursor = conn.cursor()
    
    # Статистика по всем таблицам
    tables = [
        'document_type', 'aircrafts', 'airports', 'tariffs', 
        'ticket_type', 'passengers', 'seat_maps', 'seats',
        'flights', 'seats_on_flight', 'bookings', 'payments'
    ]
    
    total_records = 0
    for table in tables:
        cursor.execute(f"SELECT COUNT(*) FROM {table}")
        count = cursor.fetchone()[0]
        total_records += count
        print(f"   • {table}: {count:,}")
    
    print("-"*50)
    print(f"   📈 ВСЕГО ЗАПИСЕЙ: {total_records:,}")
    
    # Дополнительная аналитика
    print("\n📈 ДЕТАЛЬНАЯ АНАЛИТИКА ДАННЫХ:")
    
    # Статистика бронирований
    cursor.execute("""
        SELECT 
            status,
            COUNT(*) as count,
            ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM bookings), 2) as percentage
        FROM bookings 
        GROUP BY status 
        ORDER BY count DESC
    """)
    print("  📅 Бронирования по статусам:")
    for status, count, percentage in cursor.fetchall():
        print(f"    • {status}: {count:,} ({percentage}%)")
    
    # Статистика платежей
    cursor.execute("""
        SELECT 
            payment_status,
            COUNT(*) as count,
            ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM payments), 2) as percentage
        FROM payments 
        GROUP BY payment_status 
        ORDER BY count DESC
    """)
    print("  💳 Платежи по статусам:")
    for status, count, percentage in cursor.fetchall():
        print(f"    • {status}: {count:,} ({percentage}%)")
    
    # Заполненность рейсов
    cursor.execute("""
        SELECT 
            COUNT(DISTINCT f.id_flight) as total_flights,
            COUNT(DISTINCT CASE WHEN b.status = 'CONFIRMED' THEN b.seats_on_flight_id_seats END) as confirmed_seats,
            COUNT(DISTINCT CASE WHEN b.status = 'PENDING' THEN b.seats_on_flight_id_seats END) as pending_seats,
            ROUND(COUNT(DISTINCT CASE WHEN b.status IN ('CONFIRMED', 'PENDING') THEN b.seats_on_flight_id_seats END) * 100.0 / 
                 (SELECT COUNT(*) FROM seats_on_flight), 2) as total_occupancy_rate
        FROM flights f
        LEFT JOIN bookings b ON EXISTS (
            SELECT 1 FROM seats_on_flight sof 
            WHERE sof.flights_id_flight = f.id_flight 
            AND sof.id_seat_on_flight = b.seats_on_flight_id_seats
        )
    """)
    stats = cursor.fetchone()
    print("  🛫 Заполненность рейсов:")
    print(f"    • Всего рейсов: {stats[0]:,}")
    print(f"    • Забронированных мест: {stats[1]:,}")
    print(f"    • Заблокированных мест: {stats[2]:,}")
    print(f"    • Общая заполненность: {stats[3]}%")
    
    # Возрастное распределение пассажиров
    cursor.execute("""
        SELECT 
            CASE 
                WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) < 2 THEN 'Младенцы (0-2)'
                WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) < 12 THEN 'Дети (2-12)'
                WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) < 18 THEN 'Подростки (12-18)'
                WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) < 30 THEN 'Молодежь (18-30)'
                WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) < 60 THEN 'Взрослые (30-60)'
                ELSE 'Пожилые (60+)'
            END as age_group,
            COUNT(*) as count,
            ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM passengers), 2) as percentage
        FROM passengers
        GROUP BY age_group
        ORDER BY count DESC
    """)
    print("  👥 Возрастное распределение пассажиров:")
    for age_group, count, percentage in cursor.fetchall():
        print(f"    • {age_group}: {count:,} ({percentage}%)")
    
    # Распределение классов мест
    cursor.execute("""
        SELECT 
            seat_class,
            COUNT(*) as count,
            ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM seats), 2) as percentage
        FROM seats
        GROUP BY seat_class
        ORDER BY count DESC
    """)
    print("  💺 Распределение классов мест:")
    for seat_class, count, percentage in cursor.fetchall():
        print(f"    • {seat_class}: {count:,} ({percentage}%)")
    
    cursor.close()
    print("="*70)

def main():
    """Основная функция"""
    print("="*70)
    print("🚀 ЗАПОЛНЕНИЕ БАЗЫ ДАННЫХ ТЕСТОВЫМИ ДАННЫМИ")
    print("="*70)
    print(f"Будет создано ОГРОМНОЕ количество данных:")
    print(f"  • Самолетов: {NUM_RECORDS['aircrafts']:,}")
    print(f"  • Аэропортов: {NUM_RECORDS['airports']:,}")
    print(f"  • Пассажиров: {NUM_RECORDS['passengers']:,}")
    print(f"  • Рейсов: {NUM_RECORDS['flights']:,}")
    print(f"  • Бронирований: {NUM_RECORDS['bookings']:,}")
    print(f"  • Платежей: {NUM_RECORDS['payments']:,}")
    print("="*70)
    
    # Время начала
    start_time = time.time()
    
    # Подключение к БД
    conn = create_connection()
    
    if not conn:
        print("❌ Не удалось подключиться к базе данных.")
        print("   Проверьте параметры подключения в DB_CONFIG")
        return
    
    try:
        # 1. Очистка данных
        clear_existing_data(conn)
        
        # 2. Заполнение справочников
        generate_document_types(conn)
        generate_aircrafts(conn)
        generate_airports(conn)
        generate_tariffs(conn)
        generate_ticket_types(conn)
        
        # 3. Проверка покрытия возрастов
        verify_ticket_type_coverage(conn)
        
        # 4. Заполнение основных таблиц
        generate_passengers(conn)
        
        # Исправляем количество карт мест
        NUM_RECORDS['seat_maps'] = min(NUM_RECORDS['seat_maps'], NUM_RECORDS['aircrafts'])
        
        generate_seat_maps(conn)
        generate_seats(conn)
        generate_flights(conn)
        generate_seats_on_flight(conn)
        
        # 5. Создание триггеров
        create_triggers_and_indexes(conn)
        
        # 6. Заполнение транзакционных данных
        generate_bookings(conn)
        generate_payments(conn)
        
        # 7. Обновление статусов мест
        update_seat_availability(conn)
        
        # 8. Финальная статистика
        print_final_statistics(conn)
        
        # 8. Время выполнения
        total_time = time.time() - start_time
        minutes = int(total_time // 60)
        seconds = total_time % 60
        
        print("="*70)
        print(f"✅ ЗАПОЛНЕНИЕ ЗАВЕРШЕНО!")
        print(f"⏱️  Время выполнения: {minutes} мин {seconds:.2f} сек")
        print("="*70)
        
    except Exception as e:
        print(f"\n❌ КРИТИЧЕСКАЯ ОШИБКА: {e}")
        import traceback
        traceback.print_exc()
        print("\n⚠️ Произошла ошибка. Проверьте логи выше.")
        
    finally:
        if conn:
            conn.close()
            print("🔌 Подключение к БД закрыто")

if __name__ == "__main__":
    # Проверка наличия библиотек
    try:
        import mysql.connector
        from faker import Faker
    except ImportError as e:
        print(f"❌ Не хватает библиотеки: {e}")
        print("Установите необходимые библиотеки:")
        print("  pip install mysql-connector-python faker")
        exit(1)
    
    main()